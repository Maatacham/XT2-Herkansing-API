    const x = document.getElementById("coord");
    
    function getLocation() {
      try {
        navigator.geolocation.getCurrentPosition(showPosition);
} catch {
        x.innerHTML = err;
      }
    }
    
    function showPosition(position) {
      x.innerHTML = "<span class='beschrijving'>Latitude: </span>" + position.coords.latitude + 
      "<span class='beschrijving'><br>Longitude: </span>" + position.coords.longitude;
    }