
function getAPIdata() {

	// construct request
	var request = 'https://api.openweathermap.org/data/2.5/weather?appid=5477f3a375c764afe230a6b8940691bd&q=the%20Hague,nl';

	// get current weather
	fetch(request)	
	
	// parse response to JSON format
	.then(function(response) {
		return response.json();
	})
	
	// do something with response
	.then(function(response) {
		// show full JSON object
		console.log(response.main.temp - 273.15);
		console.log(response);
		var weatherBox = document.getElementById('weather');
		weatherBox.innerHTML = "<span class='beschrijving'>Temperatuur: </span>" +(response.main.temp - 273.15).toFixed(0) + ' &#176;C ' + "<br />" + 
		"<span class='beschrijving'> Weer: </span>" + response.weather[0].description + "<br />" + "<span class='beschrijving'> Windkracht: </span>" +
		 response.wind.speed + ' km/u' + "<br />" + "<span class='beschrijving'> Zichtbaarheid: </span>" + response.visibility + 'm';
	});
}

// init data stream
getAPIdata();